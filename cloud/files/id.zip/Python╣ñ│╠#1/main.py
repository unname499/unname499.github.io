import configparser

if input("是否设置config.ini文件？（t/f）") == "t":
    import signin

cfgpath = "config.ini"
conf = configparser.ConfigParser()
conf.read(cfgpath, encoding="utf-8")

while True:
    c = input("请输入要查询的用户（键入/-exit-/退出）：")
    if c == "/-exit-/":
        break
    else:
        try:
            print(conf.get('userinfo',c))
        except Exception as e:
            print("错误！（错误信息： " + str(e) + " ）")