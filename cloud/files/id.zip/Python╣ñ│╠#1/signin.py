import configparser
import os
import random as r
if os.path.exists("config.ini") == True:
    if input("要删除config.ini文件吗？（t/f） ") == "t":
        os.remove("config.ini")

cfgpath = "config.ini"
conf = configparser.ConfigParser()
conf.read(cfgpath, encoding="utf-8")
username = ""
username_list = []
usernum = ""
if not conf.has_section ("userinfo"):
    conf.add_section("userinfo")

temp0 = int(input("请输入要注册多少人："))
for i in range(1,temp0+1):
    username = input("请输入第" + str(i) + "个人的名称：")
    conf.set("userinfo",username,str(r.randrange(0,10000000000)))
    conf.write(open(cfgpath,"w"))
    username_list.append(username)
for j in range(1,temp0+1):
    print("第" + str(j) + "个人的id：",conf.get('userinfo',username_list[j-1]),sep="")