import random as r
xiaoxiezimu = "qwertyuiopasdfghjklzxcvbnm"
fuhao = '''[]\;',./{}|:"<>?!@#$%^&*() '''
daxiezimu = "QWERTYUIOPASDFGHJKLZXCVBNM"

with open('安全密码5000个.txt', 'w',encoding="utf-8") as f:
    f.write("")

for j in range(1,5001):
    keys=""
    for i in range(1,5):
        keys = keys + r.choice(xiaoxiezimu) + r.choice(fuhao) + r.choice(daxiezimu)+ r.choice(fuhao)+ r.choice(fuhao)
    with open('安全密码5000个.txt', 'a',encoding="utf-8") as f:
        f.write(f"第{j}个："+keys+"\n")